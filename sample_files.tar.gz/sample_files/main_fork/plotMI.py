import numpy as np
import glob

from matplotlib import use
use('agg')

import matplotlib.pyplot as plt


def main():
    for ll in range(8,24,4):
        files = glob.glob("MI_L%g.dat"%(ll))
        t = np.loadtxt('betas.dat')
        for f in files:
            d = np.loadtxt(f)
            L = f.split('_')[1]
            L = L.split('.dat')[0]
            L = int(L.split('L')[1])
            print('L = ', L)
            f2 = f.split('MI')[1]
            f2 = 'MIE' + f2
            e = np.loadtxt(f2)
            plt.errorbar(t, d[:,np.int(L/2)]/L, yerr=e[:,np.int(L/2)]/L)
            print(t, d[:,np.int(L/2)]/L)
    return np.int(L)

if __name__ == "__main__":
    L = main()
    plt.savefig('test_L%g.pdf' % (L))
