"""
Analysis script for 2D Ising model
"""

import tarfile
import numpy as np
from jackknife import jackknife as jk

def loadTemps():
    r = []
    fin = open('betas.dat')
    for i in fin:
        r.append(float(i))
    return r

def analyze(L=8,ndis=16,jobnum=1, ex=''):
    betas = loadTemps()
        
    dis = range(ndis*(jobnum)+1)
    #print(dis)
    t_entf = [[[0. for i in range(L+1)] for z in dis] for zz in betas]
    t_entr = [[[0. for i in range(L+1)] for z in dis] for zz in betas]
    print('analyze code jobnum',jobnum)            
    for ii in range(jobnum):
        filef = "L%d%s/data_%g.tar"
        filer = "L%d%sr/data_%g.tar"
        fmt = "r%03d/R%03d/obs_ratio_%01.6f"
        #disorders = range(128)
        disorders = range(ndis)
        sizes = range(0,L)
        #print('ii',ii)
        dataf = tarfile.open(filef % (L,ex,ii),'r')
        for Bn,BB in enumerate(betas):
            for DD in disorders:
                for SS in sizes:
                    f = np.loadtxt(dataf.extractfile(fmt % (DD,SS,BB)))
                    val = f.mean()
                    t_entf[Bn][ndis*ii+DD][SS+1] += -1*np.log(val) + t_entf[Bn][ndis*ii+DD][SS]
        dataf.close()
    
        datar = tarfile.open(filer % (L,ex,ii),'r')
        for Bn,BB in enumerate(betas):
            for DD in disorders:
                for SS in sizes:
                    f = np.loadtxt(datar.extractfile(fmt % (DD,SS,BB)))
                    val = f.mean()
                    t_entr[Bn][ndis*ii+DD][SS+1] += -1*np.log(val) + t_entr[Bn][ndis*ii+DD][SS]
        datar.close()
    
    t_mi = [[[0. for i in range(L+1)] for z in dis] for zz in betas]
    for Bn,BB in enumerate(betas):
        for DD in dis:
            for SS in sizes:
                t_mi[Bn][DD][SS+1] = 0.5*(
                (t_entf[Bn][DD][SS+1] + t_entr[Bn][DD][SS+1]) +
                (t_entf[Bn][DD][-1*SS-2] + t_entr[Bn][DD][-1*SS-2]) -
                (t_entf[Bn][DD][-1] + t_entr[Bn][DD][-1])
                )
    
    t_mi = np.array(t_mi)
    final = [[0. for i in range(L+1)] for zz in betas]
    finalE = [[0. for i in range(L+1)] for zz in betas]
    func = lambda X: X[0].mean()
    for Bn,BB in enumerate(betas):
        for SS in sizes:
            val, err = jk([t_mi[Bn,:,SS+1]],func)
            final[Bn][SS+1] = val
            finalE[Bn][SS+1] = err
    np.savetxt('MI_L%d%s.dat' % (L,ex), np.array(final))
    np.savetxt('MIE_L%d%s.dat' % (L,ex), np.array(finalE))

if __name__ == "__main__":
    sizein = open('SIZE','r')
    L = int(sizein.readline().split()[1])
    sizein.close()
    
    sizein = open('Disorder','r')
    ndis = int(sizein.readline().split()[1])
    sizein.close()
    #print(ndis)
    sizein = open('jobNum','r')
    jobnum = int(sizein.readline().split()[1])
    #jobnum += 1
    #print('before jobnum',jobnum)
    sizein.close()
    
    #analyze(4)
    #analyze(6)
    analyze(L,ndis,jobnum)
