#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep  8 16:58:06 2017

@author: pvsl
"""

import os
import subprocess as sp


def jobNum():
    n = 0
    try:
        fin = open('jobNum','r')
        for i in fin:
            n += 1
        fin.close()
    except IOError:
        pass
    return n

#Change working directory to current directory.
#$ -cwd
def main():
    sizein = open('SIZE','r')
    L = int(sizein.readline().split()[1])
    sizein.close()
    path = os.getcwd() + '/main_fork/'
    path1 = os.getcwd() + '/main_fork/L%g'%(L)
    os.chdir(path1)
    #print(tester)
    #sp.call('. ./tar_stuff',cwd=path1,shell = True)
    n1 = jobNum();
    f = 'data.tar'    
    f1 = 'data_%g.tar'%(n1-1)
    sp.call('mv '+ f + ' ' + f1,cwd=path1,shell = True)
    
    path2 = path + '/L%gr'%(L)
    os.chdir(path2)    

    #sp.call('. ./tar_stuff',shell = True)
    n2 = jobNum();
    f = 'data.tar'    
    f1 = 'data_%g.tar'%(n2-1)    
    sp.call('mv '+ f + ' ' + f1,cwd=path2,shell = True)

    os.chdir(path)
    
    fout = open('jobNum','w')
    fout.write('N= %d\n' % n1)
    fout.close()
    
    sp.call('python analyze_MI.py',shell = True)
    sp.call('python plotMI.py',shell = True)
    
    
if __name__ == "__main__":
    main()
