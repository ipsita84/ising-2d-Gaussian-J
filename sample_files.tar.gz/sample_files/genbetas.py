import math
import numpy as np

tc = math.log(1+2**0.5)/2.

b = [i for i in np.arange(0.04,0.84,0.02)]
#b = [0.1*tc*i for i in range(1,26)]

b = list(set(b))
b = sorted(b,key=lambda x:x)

fout = open('betas.dat','w')
for i in b:
    fout.write('%0.10f\n' % i)
fout.close()
