"""
Script taking care of submitting jobs to the cluster
All steps till running on the cluster are done here 
P.V. Sriluckshmy

"""
import os
import subprocess as sp

#Change working directory to current directory.
#$ -cwd
def main():
    sizein = open('SIZE','r')
    L = int(sizein.readline().split()[1])
    sizein.close()
    
    
    
    sp.call('make',shell=True)
    sp.call('mv Ising.out main_fork/',shell=True)
    sp.call('cp param_template.dat main_fork/',shell=True)
    sp.call('cp param_template_r.dat main_fork/',shell=True)
    sp.call('cp submit_cluster.py main_fork/',shell=True)
    sp.call('cp submit_cluster_r.py main_fork/',shell=True)
    sp.call('cp SIZE main_fork/',shell=True)
    sp.call('cp Disorder main_fork/',shell=True)
    sp.call('cp Jval main_fork/',shell=True)
    sp.call('cp Prob main_fork/',shell=True)
    sp.call('cp betas.dat main_fork/',shell=True)
    #sp.call('cd main_fork/',shell=True)
    full_path = os.getcwd() + '/main_fork'
    sp.call('python makedirs.py',cwd=full_path,shell = True)
    path1 = os.getcwd() + '/main_fork/L%g'%(L)
    sp.call('python submit_cluster.py',cwd=path1,shell = True)
    path2 = os.getcwd() + '/main_fork/L%gr'%(L)
    sp.call('python submit_cluster_r.py',cwd=path2,shell = True)
    
    
if __name__ == "__main__":
    main()
