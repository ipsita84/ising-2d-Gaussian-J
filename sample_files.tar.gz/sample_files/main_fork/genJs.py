"""
Script for submitting jobsto the ASC cluster
for the 'lowa' code, simulating over a range of 
sizes and temperature, and a fixed size of region A

Stephen Inglis, 02.28.2014

"""

import os
#import subprocess as sp
import numpy as np

def main():
    #pathformat = 'L%03d/b%0.6f'
    pathformat = 'r%03d'
    #disorders = 32
    #L = 16
    sizein = open('SIZE','r')
    L = int(sizein.readline().split()[1])
    sizein.close()
    
    probin = open('Prob','r')
    P = float(probin.readline().split()[1])
    probin.close()
    
    disin = open('Disorder','r')
    disorders = int(disin.readline().split()[1])
    disin.close()
    jj = open('Jval','r')
    J = float(jj.readline().split()[1])
    jj.close()
    
    #disorders = ndis
    for D in range(0,disorders+0):
        curr_path = pathformat % D
        #print('path',curr_path)
        try:
            #print('trying')
            os.makedirs(curr_path)
        except OSError:
            print('error')
            pass
        fout = open(curr_path + '/Jmat.dat','w')
        
        #Jval = np.random.randint(2, size=L**2 * 2) - 0.5
        #print(Jval)
        #while np.abs(np.sum(Jval)) > 1e-6 :
        #    Jval = np.random.randint(2, size=L**2 * 2) - 0.5
            #print(Jval)
        #Jval = 2*Jval;    
        for i in range(L**2 * 2):
            #tt = J*Jval[i]
            a = np.random.randint(2,size=1)
            if a < 1:
                tt = -J
            else:
                tt = -0.5*J
            fout.write("%1.8f " % tt)
        fout.close()

if __name__ == "__main__":
    main()
